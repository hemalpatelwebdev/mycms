<footer id="main-footer" class="bg-dark text-white m-0">
    <div class="container">
        <div class="row">
            <div class="col text-center py-3">
                <p>Copyright &copy; hemalpatewebdev.com/mycms {{\Carbon\Carbon::now()->year}}</p>
            </div>
        </div>
    </div>
</footer>