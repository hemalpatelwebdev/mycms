@extends('layouts.app')

@section('content')

    <h2>The page you are looking is not found</h2>

@endsection