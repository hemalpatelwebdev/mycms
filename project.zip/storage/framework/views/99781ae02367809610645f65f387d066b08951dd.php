<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/libs/bootstrap.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('vendor/fontawesome/css/all.min.css')); ?>" rel="stylesheet" type="text/css">

    <style>
        body{
            overflow-x: hidden;
        }
        main {
            margin-top: 100px;
            min-height: 78vh;
        }
        footer{
            overflow: hidden;
        }
    </style>
</head>
<body>
    <div id="app">
        

        <nav class="navbar navbar-expand-sm bg-dark navbar-dark fixed-top" id="main-nav">
            <div class="container">
                <?php if(Auth::guest()): ?>
                    <a class="navbar-brand" href="<?php echo e(route('index')); ?>">Web Tricks</a>
                <?php else: ?>
                    <a class="navbar-brand" href="<?php echo e(route('home')); ?>">Web Tricks</a>
                <?php endif; ?>
                <button class="navbar-toggler" data-toggle="collapse" data-target="#mainNavbarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="mainNavbarCollapse">
                    <ul class="navbar-nav ml-auto">
                        <?php if(Auth::guest()): ?>
                            <li class="nav-item mr-4"><a href="<?php echo e(route('login')); ?>" class="<?php echo e(Request::is('login')? 'nav-link active' : 'nav-link'); ?>">Login</a></li>
                            <li class="nav-item mr-4"><a href="<?php echo e(route('register')); ?>" class="<?php echo e(Request::is('register')? 'nav-link active' : 'nav-link'); ?>">Register</a></li>
                            <li class="nav-item mr-4"><a href="#" class="<?php echo e(Request::is('contact')? 'nav-link active' : 'nav-link'); ?>">Contact</a></li>
                        <?php else: ?>
                            <?php if(Auth::user()->isAdmin() || Auth::user()->isAuthor()): ?><li class="nav-item mr-4"><a href="<?php echo e(route('admin.index')); ?>" class="<?php echo e(Request::is('admin')? 'nav-link active' : 'nav-link'); ?>">Admin</a></li><?php endif; ?>
                            <li class="nav-item dropdown no-arrow">
                                <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                  <span class="mr-2 d-none d-lg-inline text-gray-600 small"></span>
                                  <?php echo e(Auth::user()->name); ?><i class="ml-2 fas fa-user fa-sm"></i>
                                </a>
                                <!-- Dropdown - User Information -->
                                <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                                  <a class="dropdown-item" href="#">
                                    <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Settings
                                  </a>
                                  <div class="dropdown-divider"></div>
                                  <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    <?php echo e(__('Logout')); ?>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                  </a>
                                </div>
                              </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        <?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</body>
</html>
<?php /**PATH /home/vagrant/Code/codehacking/resources/views/layouts/app.blade.php ENDPATH**/ ?>