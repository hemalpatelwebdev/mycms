<?php $__env->startSection('content'); ?>


    <h1>Categories</h1>
    <br/>
    <?php if(Session::has('category_deleted')): ?>
        <p class='bg-info'><?php echo e(Session::get('category_deleted')); ?> </p>
    <?php endif; ?>
    <div class="col-sm-6">
        <?php echo Form::open(['method'=>'POST','action'=>'AdminCategoriesController@store']); ?>

            <div class="form-group">
                <?php echo Form::label('category','Category Name:'); ?>

                <?php echo Form::text('name', null, ['required'=>'required','class'=>'form-control']); ?>

            </div>
            <div class="form-group">
                <?php echo Form::submit('Create Category',['class'=>'btn btn-primary']); ?>

            </div>

        <?php echo Form::close(); ?>

    </div>
    <div class="col-sm-6">
    <table class="table">
        <thead>
            <th>Id</th>
            <th>Name</th>
            <th>Created</th>
        </thead>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($category->id); ?></td>
                <td><a href="<?php echo e(route('categories.edit',$category->id)); ?>"><?php echo e($category->name); ?></a></td>
                <td><?php echo e($category->created_at->diffForHumans()); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/Code/codehacking/resources/views/admin/categories/index.blade.php ENDPATH**/ ?>