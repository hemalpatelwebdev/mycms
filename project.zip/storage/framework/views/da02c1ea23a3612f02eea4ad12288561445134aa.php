




<?php $__env->startSection('content'); ?>


    <h1>Comments Replies</h1>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/Code/codehacking/resources/views/admin/comments/replies/index.blade.php ENDPATH**/ ?>