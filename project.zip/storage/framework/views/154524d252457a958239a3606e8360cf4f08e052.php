

<?php $__env->startSection('content'); ?>

    <?php if(Session::has('users_deleted')): ?>
        <p class='bg-info'><?php echo e(Session::get('users_deleted')); ?> </p>
    <?php endif; ?>

    <h1>Users</h1>
    <table class="table">
        <thead class="thead-dark">
            <th></th>
            <th>Name</th>
            <th>Role</th>
            <th>Status</th>
            <th>Email</th>
            <th>Created</th>
            <th>Updated</th>
        </thead>
        <tbody>
            <?php if($users): ?>
                
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><img width = "35" height = "35" src = "<?php echo e($user->photo ? $user->photo->path : ''); ?>"></td>
                        <td><a href="<?php echo e(route('users.edit',$user->id)); ?>"><?php echo e($user->name); ?></a></td>
                        <td><?php echo e($user->role->name); ?></td>
                        <td><?php echo e($user->is_active == 1 ? 'Active' : 'Not Active'); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->created_at->diffForHumans()); ?></td>
                        <td><?php echo e($user->updated_at->diffForHumans()); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
    </table>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/Code/codehacking/resources/views/admin/users/index.blade.php ENDPATH**/ ?>