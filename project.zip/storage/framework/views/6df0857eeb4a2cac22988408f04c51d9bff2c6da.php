

<?php $__env->startSection('content'); ?>
    <!-- Blog Post -->

    <!-- Title -->
    <h1><?php echo e($post->title); ?></h1>

    <!-- Author -->
    <p class="lead">
        by <a href="#"><?php echo e($post->user->name); ?></a>
    </p>

    <hr>

    <!-- Date/Time -->
    <p><span class="glyphicon glyphicon-time"></span> Posted on <?php echo e($post->created_at->diffForHumans()); ?></p>

    <hr>
    <hr>

    <!-- Post Content -->
    <p class="lead"><?php echo $post->body; ?></p>

    <hr>

    <!-- Blog Comments -->

    <!-- Comments Form -->
    <?php if(Session::has('comment_success')): ?>
        <div class="alert alert-success">
            <?php echo e(Session('comment_success')); ?>

        </div>
    <?php endif; ?>

    
    <div class="well">
        <?php if(Auth::check()): ?>
            <h4>Leave a Comment:</h4>
        <?php echo Form::open(['method'=>'POST','action'=>'PostCommentsController@store']); ?>

            <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
            <div class="form-group">
                <?php echo Form::textarea('body', null, ['class'=>'form-control','rows'=>3]); ?>

            </div>
            <?php echo Form::submit('Submit Comment', ['class'=>'btn btn-primary']); ?>

        <?php echo Form::close(); ?>

        <?php else: ?>
            <h5>Please login to comment</h5>
        <?php endif; ?>
    </div>


    <hr>

    <!-- Posted Comments -->
    <?php if(count($comments)>0): ?>
    <!-- Comment -->
        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="media">
            <a class="pull-left" href="#">
                <img height="64" width="64" class="media-object" src="<?php echo e($comment->photo); ?>" onerror="this.src='http://placehold.it/64x64';">
            </a>
            <div class="media-body">
                <h4 class="media-heading"><?php echo e($comment->author); ?>

                    <small><?php echo e($comment->created_at->diffForHumans()); ?></small>
                </h4>
                <p><?php echo e($comment->body); ?></p>
                <a class="toggle-reply">View Replies</a>
                <span class="view-reply-container">
                    <!-- Nested Comment -->
                    <?php if(count($comment->replies) > 0): ?>
                        <?php $__currentLoopData = $comment->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($reply->is_active == 1): ?>
                            <div class="media">
                                <a class="pull-left" href="#">
                                    <img height="64" width="64" class="media-object" src="<?php echo e($reply->photo); ?>" onerror="this.src='http://placehold.it/64x64';" alt="">
                                </a>
                                <div class="media-body">
                                    <h4 class="media-heading"><?php echo e($reply->title); ?>

                                        <small><?php echo e($reply->created_at->diffForHumans()); ?></small>
                                    </h4>
                                    <?php echo e($reply->body); ?>

                                </div>
                            </div><br/>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!-- End Nested Comment -->
                <?php else: ?>
                    <h5 class="text-center">No Replies</h5>
                <?php endif; ?>
                </span>
                <?php if(Auth::check()): ?>
                <?php echo Form::open(['method'=>'POST','action'=>'CommentsRepliesController@createReply']); ?>

                        <input type="hidden" name="comment_id" value="<?php echo e($comment->id); ?>">
                        <div class="form-group">
                            <?php echo Form::textarea('body',null,['class'=>'form-control', 'placeholder'=>'Leave your reply here', 'rows'=>1]); ?>

                        </div>
                        <?php if(Session::has('reply_created')): ?>
                            <p><?php echo e(Session('reply_created')); ?></p>
                        <?php endif; ?>
                        <?php echo Form::submit('Submit Reply',['class'=>'btn btn-primary']); ?>

                <?php echo Form::close(); ?>

                <?php else: ?>
                    <h6 class="text-left">Please login to reply</h5>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
        <script>
            $(".toggle-reply").click(function(){
                $(this).next().slideToggle("show");
                if($(".toggle-reply").html() == 'View Replies') {
                    $(".toggle-reply").html("Hide Replies");
                }
                else{
                    $(".toggle-reply").html("View Replies");
                }
            });
        </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.blog-post', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/Code/codehacking/resources/views/post.blade.php ENDPATH**/ ?>