

<?php $__env->startSection('content'); ?>

    <?php if(count($comments) > 0): ?>
    <table class="table">
        <thead>
            <tr>
                <th>Id</th>
                <th>Author</th>
                <th>Email</th>
                <th>Body</th>
                <th>Post</th>
            </tr>
        </thead>
        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($comment->id); ?></td>
            <td><?php echo e($comment->author); ?></td>
            <td><?php echo e($comment->email); ?></td>
            <td><?php echo e($comment->body); ?></td>
            <td><a href="<?php echo e(route('home.post',$comment->post->id)); ?>">View Post</a></td>
            <td>
                <?php if($comment->is_active == 1): ?>
                    <?php echo Form::open(['method' => 'PATCH', 'action' => ['PostCommentsController@update',$comment->id]]); ?>

                        <input type="hidden" name="is_active" value=0>
                        <?php echo Form::submit('Disapprove',['class'=>'btn btn-warning']); ?>

                    <?php echo Form::close(); ?>

                <?php else: ?>
                    <?php echo Form::open(['method' => 'PATCH', 'action' => ['PostCommentsController@update',$comment->id]]); ?>

                        <input type="hidden" name="is_active" value=1>
                        <?php echo Form::submit('Approve',['class'=>'btn btn-success']); ?>

                    <?php echo Form::close(); ?>

                <?php endif; ?>
            </td>
            <td>
                <?php echo Form::open(['method' => 'DELETE', 'action' => ['PostCommentsController@destroy',$comment->id]]); ?>

                        <?php echo Form::submit('Delete',['class'=>'btn btn-danger']); ?>

                <?php echo Form::close(); ?>

            </td>
        <tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <?php else: ?>
        <h1 class='text-center'>No Comments found for this post</h1>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/Code/codehacking/resources/views/admin/comments/show.blade.php ENDPATH**/ ?>