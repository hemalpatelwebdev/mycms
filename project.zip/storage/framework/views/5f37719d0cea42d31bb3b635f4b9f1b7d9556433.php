<?php $__env->startSection('content'); ?>

    <h1>Admin</h1>
    <canvas id="myChart"></canvas>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.8.0"></script>
    <script>
        var ctx = document.getElementById('myChart').getContext('2d');
        var chart = new Chart(ctx, {
            // The type of chart we want to create
            type: 'bar',

            // The data for our dataset
            data: {
                labels: ['Posts', 'Categories', 'Comments'],
                datasets: [{
                    label: 'Data of CMS',
                    data: [<?php echo e($postCount); ?>, <?php echo e($categoryCount); ?>, <?php echo e($commentCount); ?>],
                    backgroundColor: [
                        'rgb(255, 99, 132, 0.2)',
                        'rgb(54, 162, 235, 0.2)',
                        'rgb(255, 159, 64, 0.2)',
                        'rgb(153, 102, 255, 0.2)',
                    ],
                    borderColor: [
                        'rgb(255, 99, 132)',
                        'rgb(54, 162, 235)',
                        'rgb(255, 159, 64)',
                        'rgb(153, 102, 255)',
                    ],
                }]
            },

            // Configuration options go here
            options: {}
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/Code/codehacking/resources/views/admin/index.blade.php ENDPATH**/ ?>