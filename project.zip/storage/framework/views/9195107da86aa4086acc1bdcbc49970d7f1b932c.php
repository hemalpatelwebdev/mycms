<?php $__env->startSection('content'); ?>
<?php echo $__env->make('include.tinyeditor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <h1>Create Post</h1>

    <div class='row'>
        <div class="col-sm-12">
            <?php echo Form::open(['method'=>'post', 'action' => 'AdminPostsController@store', 'files'=>true]); ?>


            <div class='form-group'>
                <?php echo Form::label('title', 'Title:'); ?>

                <?php echo Form::text('title', null, ['class' => 'form-control']); ?>

            </div>
            <div class='form-group'>
                <?php echo Form::label('category_id', 'Category:'); ?>

                <?php echo Form::select('category_id', [''=>'Please Choose'] + $categories, null, ['class' => 'form-control']); ?>

            </div>
            <div class='form-group'>
                <?php echo Form::label('body', 'Body:'); ?>

                <?php echo Form::textarea('body', ['class' => 'form-control']); ?>

            </div>
            <div class='form-group'>
                <?php echo Form::submit('Create Post', ['class' => 'btn btn-primary btn-block']); ?>

            </div>
        <?php echo Form::close(); ?>

        </div>
   
    </div>
    <div class='row'>
        <?php echo $__env->make('include.formError', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/Code/codehacking/resources/views/admin/posts/create.blade.php ENDPATH**/ ?>