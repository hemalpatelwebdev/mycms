

<?php $__env->startSection('content'); ?>

    <?php if(Session::has('select_error') ): ?>
        <p class='bg-info'><?php echo e(Session::get('select_error')); ?> </p>
    <?php elseif(Session::has('delete_success')): ?>
        <p class='bg-info'><?php echo e(Session::get('delete_success')); ?> </p>
    <?php endif; ?>

    <?php if($photos): ?>
        <h1>All Medias</h1>
        <form action="<?php echo e(route('bulkdelete')); ?>" method="POST" class="form-inline">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('delete')); ?>

            <div class="form-group">
                <select name="checkBoxArray" id="" class="form-control">
                    <option value="delete">Delete</option>
                </select>
            </div>
            <div class="form-group">
                <input type="submit" value="Submit" class="btn btn-primary">
            </div>
            <table class="table">
                <thead>
                    <th><input type="checkbox" id="options"></th>
                    <th>Id</th>
                    <th>Photo</th>
                    <th>Created</th>
                </thead>
                <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><input class="checkBoxes" type="checkbox" name="CheckBoxArray[]" value="<?php echo e($photo->id); ?>"></td>
                        <td><?php echo e($photo->id); ?></td>
                        <td><img height="40px" width="100px" src="<?php echo e($photo->path); ?>"></td>
                        <td><?php echo e($photo->created_at->diffForHumans()); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <div class="row">
                <div class="col-sm-6 col-sm-offset-5">
                    <?php echo e($photos->render()); ?>

                </div>
            </div>
        </form>

    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

        <script>
            $(document).ready(function(){
                $('#options').click(function(){
                    if(this.checked){
                        $('.checkBoxes').each(function(){
                            this.checked = true;
                        })
                    }
                    else{
                        $('.checkBoxes').each(function(){
                            this.checked = false;
                        })
                    }
                });
            });
        </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/Code/codehacking/resources/views/admin/medias/index.blade.php ENDPATH**/ ?>