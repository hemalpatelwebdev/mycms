

<?php $__env->startSection('content'); ?>

    <h2>The page you are looking is not found</h2>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/Code/codehacking/resources/views/errors/404.blade.php ENDPATH**/ ?>