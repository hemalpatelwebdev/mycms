<?php $__env->startSection('content'); ?>

<div class="container">

    <div class="row">

        <!-- Blog Entries Column -->
        <br/><br/>
        <div class="col-md-8">
            <h1 class="page-header">
            </h1>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- First Blog Post -->
                <h2>
                    <a href="#"><?php echo e($post->title); ?></a>
                </h2>
                <p class="lead">
                    by <a href="index.php"><?php echo e($post->user->name); ?></a>
                </p>
                <p><span class="glyphicon glyphicon-time"></span> Posted on <?php echo e($post->created_at->diffForHumans()); ?></p>
                <hr>
                <p><?php echo Str::limit($post->body , 300, '....'); ?> </p>
                <a class="btn btn-primary" href="<?php echo e(route('home.post',$post->id)); ?>">Read More <span class="glyphicon glyphicon-chevron-right"></span></a>

                <hr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            

            <!-- Pagination -->
            <?php echo e($posts->render()); ?>


        </div>

        <!-- Blog Sidebar Widgets Column -->
        <div class="col-md-4">

            <!-- Blog Search Well -->
            <div class="well mb-4">
                <h4>Blog Search</h4>
                <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search for post..">
                    <div class="input-group-append">
                        <button class="btn btn-primary" type="button">
                            <i class="fa fa-search"></i>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Blog Categories Well -->
            <div class="well mb-4">
                <h4>Blog Categories</h4>
                <div class="row">
                    <div class="col-lg-6">
                        <ul class="list-unstyled">
                            <?php $categoryNum = 1 ?>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($categoryNum % 2 != 0): ?>
                                    <li>
                                        <a href="#"><?php echo e($category->name); ?></a>
                                    </li>
                                <?php endif; ?>
                                <?php $categoryNum ++ ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <div class="col-lg-6">
                        <ul class="list-unstyled">
                            <?php $categoryNum = 1 ?>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($categoryNum % 2 == 0): ?>
                                    <li>
                                        <a href="#"><?php echo e($category->name); ?></a>
                                    </li>
                                <?php endif; ?>
                                <?php $categoryNum ++ ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
                <!-- /.row -->
            </div>

            <!-- Side Widget Well -->
            <div class="well mb-4">
                <h4>Latest Site Updates</h4>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Inventore, perspiciatis adipisci accusamus laudantium odit aliquam repellat tempore quos aspernatur vero.</p>
            </div>

        </div>

    </div>
    <!-- /.row -->

    <hr>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/Code/codehacking/resources/views/home.blade.php ENDPATH**/ ?>