<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('include.tinyeditor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <h1>Edit Post</h1>
        <div class='row'>
        <?php echo Form::model($post,['method'=>'PATCH', 'action' => ['AdminPostsController@update', $post->id], 'files'=>true]); ?>

            <div class="col-sm-9">
                <div class='form-group'>
                    <?php echo Form::label('title', 'Title:'); ?>

                    <?php echo Form::text('title', null, ['class' => 'form-control']); ?>

                </div>
                <div class='form-group'>
                    <?php echo Form::label('category_id', 'Category:'); ?>

                    <?php echo Form::select('category_id', $categories, null, ['class' => 'form-control']); ?>

                </div>
                <div class='form-group'>
                    <?php echo Form::label('body', 'Body:'); ?>

                    <?php echo Form::textarea('body', null, ['class' => 'form-control']); ?>

                </div>
                <div class='form-group'>
                    <?php echo Form::submit('Update Post', ['class' => 'btn btn-primary col-sm-6']); ?>

                </div>
            
        <?php echo Form::close(); ?>

        <?php echo Form::open(['method'=>'DELETE','action'=>['AdminPostsController@destroy',$post->id]]); ?>

            <div class='form-group'>
                <?php echo Form::submit('Delete Post', ['class' => 'btn btn-danger col-sm-6']); ?>

            </div>
        <?php echo Form::close(); ?>

            </div>
        </div>
        <div class='row'>
            <?php echo $__env->make('include.formError', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/Code/codehacking/resources/views/admin/posts/edit.blade.php ENDPATH**/ ?>